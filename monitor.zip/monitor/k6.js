import http from "k6/http";
import { sleep } from "k6";

export const options = {
  vus: 5000, // virtual users
  iterations: 20000, // total req
  startTime: "0s",
};

export default function () {
  http.get("http://localhost:8080/keywords");
  sleep(1);
}
