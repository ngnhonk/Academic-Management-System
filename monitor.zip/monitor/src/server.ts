// import "loadavg-windows";
import cors from "cors";
import express, { type Express } from "express";
import helmet from "helmet";
import { pino } from "pino";
import expressStatusMonitor from "express-status-monitor";
import { healthCheckRouter } from "@/api/healthCheck/healthCheckRouter";
import { keywordRouter } from "./api/keyword/keyword.routes";
import { openAPIRouter } from "@/api-docs/openAPIRouter";
import errorHandler from "@/common/middleware/errorHandler";
import rateLimiter from "@/common/middleware/rateLimiter";
import requestLogger from "@/common/middleware/requestLogger";
import { env } from "@/common/utils/envConfig";

const logger = pino({ name: "server start" });
const app: Express = express();
app.use(
    helmet({
        contentSecurityPolicy: {
            directives: {
                "default-src": ["'self'"],
                "script-src": [
                    "'self'",
                    "https://cdnjs.cloudflare.com",
                    "'unsafe-inline'",
                ],
                "style-src": ["'self'", "'unsafe-inline'"],
                "connect-src": ["'self'", "ws:", "wss:"],
            },
        },
    })
);

// --- Monitoring ---
app.set("trust proxy", true);
app.use(
    expressStatusMonitor({
        title: "App Status",
        path: "/status",
        spans: [
            { interval: 1, retention: 60 },
            { interval: 5, retention: 60 },
            { interval: 15, retention: 60 },
        ],
        chartVisibility: {
            cpu: false,
            mem: false,
            load: false,
            heap: false,
            responseTime: true,
            rps: true,
            statusCodes: true,
        },
    })
);

// --- Common middlewares ---
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors({ origin: env.CORS_ORIGIN, credentials: true }));
app.use(rateLimiter);
app.use(requestLogger);

// --- Routes ---
app.use("/health-check", healthCheckRouter);
app.use("/keywords", keywordRouter);
app.use(openAPIRouter);

// --- Error handling ---
app.use(errorHandler());

export { app, logger };
