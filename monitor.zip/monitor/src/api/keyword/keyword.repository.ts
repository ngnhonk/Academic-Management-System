import type { Keyword } from "@/api/keyword/keywork.model";
import db from "@/configs/knex";

export class KeywordRepository {
    async getAllKeywords(): Promise<Keyword[]> {
        const result = await db("keywords").select("*");
        return result;
    }

    async getKeywordById(id: string): Promise<Keyword> {
        const result = await db("keywords").select("*").where({ id }).first();
        return result;
    }
}