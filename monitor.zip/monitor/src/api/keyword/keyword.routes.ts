import { OpenAPIRegistry } from "@asteasolutions/zod-to-openapi";
import express, { type Router } from "express";
import { z } from "zod";

import { createApiResponse } from "@/api-docs/openAPIResponseBuilders";
import { validateRequest } from "@/common/utils/httpHandlers";
import { keywordController } from "./keyword.controller";

import {
    KeywordSchema,
    GetKeywordSchema
} from "./keywork.model";

export const keywordRegistry = new OpenAPIRegistry();
export const keywordRouter: Router = express.Router();
keywordRegistry.register("Keyword", KeywordSchema);

// Get all keywords
keywordRegistry.registerPath({
    method: "get",
    path: "/keywords",
    tags: ["Keyword"],
    responses: createApiResponse(GetKeywordSchema, "Success"),
});

keywordRouter.get(
    "/",
    keywordController.getAllKeywords
);

// Get keyword by id
keywordRegistry.registerPath({
    method: "get",
    path: "/keywords/{id}",
    tags: ["Keyword"],
    request: {
        params: GetKeywordSchema.shape.params,
    },
    responses: createApiResponse(GetKeywordSchema, "Success"),
});

keywordRouter.get(
    "/:id",
    keywordController.getKeyword
);