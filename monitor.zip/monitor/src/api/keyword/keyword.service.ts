import { StatusCodes } from "http-status-codes";
import { ServiceResponse } from "@/common/models/serviceResponse";
import { logger } from "@/server";
import type { Keyword } from "./keywork.model";
import { KeywordRepository } from "./keyword.repository";

export class KeywordService {
    private keywordRepository: KeywordRepository;

    constructor(repository: KeywordRepository = new KeywordRepository()) {
        this.keywordRepository = repository;
    }
    async getAllKeywords(): Promise<ServiceResponse<Keyword[] | string | null>> {
        try {
            const result = await this.keywordRepository.getAllKeywords();
            if (!result || result.length === 0) {
                return ServiceResponse.failure(
                    "No keywords found",
                    null,
                    StatusCodes.NOT_FOUND
                );
            }
            return ServiceResponse.success<Keyword[]>("Keywords found", result);
        } catch (error) {
            const errorMessage = `Error finding all keywords: $${(error as Error).message
                }`;
            logger.error(errorMessage);
            return ServiceResponse.failure(
                "An error occurred while retrieving keywords.",
                errorMessage,
                StatusCodes.INTERNAL_SERVER_ERROR
            );
        }
    }

    async getKeywordById(
        id: string
    ): Promise<ServiceResponse<Keyword | null | string>> {
        try {
            const result = await this.keywordRepository.getKeywordById(id);
            if (!result) {
                return ServiceResponse.failure(
                    "Keyword not found",
                    null,
                    StatusCodes.NOT_FOUND
                );
            }
            return ServiceResponse.success<Keyword>("Keyword found", result);
        } catch (error) {
            const errorMessage = `Error finding keyword with id ${id}:, ${(error as Error).message
                }`;
            logger.error(errorMessage);
            return ServiceResponse.failure(
                "An error occurred while finding keyword.",
                null,
                StatusCodes.INTERNAL_SERVER_ERROR
            );
        }
    }

}

export const keywordService = new KeywordService();