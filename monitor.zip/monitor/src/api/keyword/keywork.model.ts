import { extendZodWithOpenApi } from "@asteasolutions/zod-to-openapi";
import { z } from "zod";

import { commonValidations } from "@/common/utils/commonValidation";

extendZodWithOpenApi(z);

export const KeywordSchema = z.object({
    id: z.number(),
    content: z.string(),
});

export type Keyword = z.infer<typeof Keyword>;
export const Keyword = z.object({
    id: z.number(),
    content: z.string(),
});

export const GetKeywordSchema = z.object({
    params: z.object({ id: commonValidations.id }),
});
