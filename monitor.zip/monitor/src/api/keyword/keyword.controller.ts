import type { Request, RequestHandler, Response } from "express";

import { keywordService } from "./keyword.service";

class KeywordController {
    public getAllKeywords: RequestHandler = async (req: Request, res: Response) => {
        const serviceResponse = await keywordService.getAllKeywords();
        res.status(serviceResponse.statusCode).send(serviceResponse);
    };

    public getKeyword: RequestHandler = async (req: Request, res: Response) => {
        const { id } = req.params;
        const serviceResponse = await keywordService.getKeywordById(id);
        res.status(serviceResponse.statusCode).send(serviceResponse);
    };
}

export const keywordController = new KeywordController();